import type { NextConfig } from 'next';
const nextConfig: NextConfig = { serverActions: { bodySizeLimit: '110mb' } };
export default nextConfig;
