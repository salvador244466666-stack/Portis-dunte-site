# Portis dunte

Projeto Next.js pronto para implantação na Vercel, com Supabase (banco + armazenamento privado), Resend (e-mails) e consulta opcional à API do VirusTotal.

## Configuração necessária antes de publicar

1. Crie um projeto no Supabase.
2. No SQL Editor, execute `supabase.sql`.
3. Em Storage, crie um bucket **privado** chamado `portis-files`.
4. Crie uma conta no Resend e configure/verifique um domínio de envio. Um e-mail de remetente não verificado pode não funcionar.
5. (Recomendado) Configure uma chave da API do VirusTotal. A integração consulta o SHA-256 na base; ela não envia o arquivo para análise. Se o hash ainda não existir, a publicação fica pendente.
6. Copie `.env.example` para `.env.local` e preencha as chaves. Nunca coloque `SUPABASE_SERVICE_ROLE_KEY`, `RESEND_API_KEY`, `VIRUSTOTAL_API_KEY` ou `ADMIN_TOKEN` no código do navegador.
7. Instale dependências com `npm install` e teste com `npm run dev`.
8. Envie o projeto ao GitHub e importe o repositório na Vercel. Cadastre as mesmas variáveis em Project Settings > Environment Variables e faça o deploy.

## Moderação manual

Publicações pendentes não aparecem na vitrine nem podem ser baixadas. Para aprovar ou recusar, faça uma requisição POST para `/api/admin/review` com o cabeçalho `Authorization: Bearer SEU_ADMIN_TOKEN` e JSON:

```json
{"id":"UUID_DA_PUBLICACAO","decision":"approved","reason":"Revisão concluída."}
```

Para recusar, use `"decision":"rejected"` e explique o motivo. O dono recebe e-mail após a decisão.

## Limites e segurança

- Limite de upload: 100 MB; imagem: 5 MB.
- A extensão é validada, mas extensão/MIME não provam que um binário é seguro.
- Resultado limpo do VirusTotal não é garantia de segurança. Faça revisão humana antes de distribuir arquivos desconhecidos. A análise automática só aprova um hash já consultado sem detecções; arquivos desconhecidos ficam pendentes.
- IPA pode exigir assinatura, provisionamento e meios compatíveis para instalação. O site apenas hospeda e distribui o arquivo.
- Para produção, adicione CAPTCHA, limites por IP, política de privacidade, termos, canal de denúncia e um painel de moderação autenticado.
