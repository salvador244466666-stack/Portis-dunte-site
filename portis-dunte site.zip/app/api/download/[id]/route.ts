import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/server';
export async function GET(_req:NextRequest,{params}:{params:Promise<{id:string}>}){
  try{const {id}=await params;const db=supabase();const {data,error}=await db.from('apps').select('file_path,name,platform').eq('id',id).eq('status','approved').single();if(error||!data)return NextResponse.json({error:'Aplicativo não encontrado ou não publicado.'},{status:404});const {data:link,error:linkError}=await db.storage.from('portis-files').createSignedUrl(data.file_path,60,{download:true});if(linkError||!link)return NextResponse.json({error:'Não foi possível gerar o download.'},{status:500});return NextResponse.redirect(link.signedUrl);}catch{return NextResponse.json({error:'Erro ao preparar download.'},{status:500});}
}
