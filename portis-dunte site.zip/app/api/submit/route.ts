import { NextRequest, NextResponse } from 'next/server';
import { supabase, sendOwnerEmail, checkVirusTotal } from '@/lib/server';
import { randomUUID, createHash } from 'node:crypto';
export const runtime = 'nodejs';
export const maxDuration = 60;
const MAX = 100 * 1024 * 1024;
const extByPlatform: Record<string,string> = { APK:'.apk', IPA:'.ipa', EXE:'.exe' };
export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();
    const platform = String(form.get('platform')||'');
    const name = String(form.get('name')||'').trim();
    const pkg = String(form.get('package_name')||'').trim();
    const email = String(form.get('email')||'').trim();
    const description = String(form.get('description')||'').trim();
    const contact = String(form.get('contact')||'').trim();
    const file = form.get('file');
    const image = form.get('image');
    if (!['APK','IPA','EXE'].includes(platform) || !name || !pkg || !email || !(file instanceof File) || !(image instanceof File) || form.get('rights') !== 'on') return NextResponse.json({error:'Preencha os campos obrigatórios e confirme que tem direito de compartilhar o arquivo.'},{status:400});
    if (file.size < 1 || file.size > MAX) return NextResponse.json({error:'O arquivo deve ter até 100 MB.'},{status:400});
    const lower = file.name.toLowerCase();
    if (!lower.endsWith(extByPlatform[platform])) return NextResponse.json({error:`O formato selecionado exige um arquivo ${extByPlatform[platform]}.`},{status:400});
    if (!['image/png','image/jpeg','image/webp'].includes(image.type) || image.size > 5*1024*1024) return NextResponse.json({error:'A imagem deve ser PNG, JPG ou WEBP e ter até 5 MB.'},{status:400});
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return NextResponse.json({error:'Informe um e-mail válido.'},{status:400});
    const buffer = Buffer.from(await file.arrayBuffer());
    const digest = createHash('sha256').update(buffer).digest('hex');
    const scan = await checkVirusTotal(buffer);
    const id = randomUUID();
    let status = 'pending';
    let reason = scan.reason;
    if (scan.status === 'malicious') { status = 'rejected'; reason = scan.reason + ' O arquivo não foi publicado.'; }
    else if (scan.status === 'clean') { status = 'approved'; reason = 'Verificação automatizada sem detecções conhecidas. Isso não garante segurança total.'; }
    const db = supabase();
    const filePath = `${id}/${file.name.replace(/[^a-zA-Z0-9._-]/g,'_')}`;
    const imagePath = `${id}/cover-${image.name.replace(/[^a-zA-Z0-9._-]/g,'_')}`;
    const { error: uploadErr } = await db.storage.from('portis-files').upload(filePath, buffer, { contentType:file.type || 'application/octet-stream', upsert:false });
    if (uploadErr) throw new Error('Falha ao armazenar o aplicativo. Confira a configuração do Supabase.');
    const { error: imageErr } = await db.storage.from('portis-files').upload(imagePath, Buffer.from(await image.arrayBuffer()), { contentType:image.type, upsert:false });
    if (imageErr) { await db.storage.from('portis-files').remove([filePath]); throw new Error('Falha ao armazenar a imagem.'); }
    const { error: insertErr } = await db.from('apps').insert({ id, name, platform, package_name:pkg, description:description||null, contact:contact||null, owner_email:email, file_path:filePath, image_path:imagePath, sha256:digest, status, moderation_reason:reason });
    if (insertErr) { await db.storage.from('portis-files').remove([filePath,imagePath]); throw new Error('Falha ao registrar a publicação. Confira a tabela apps no Supabase.'); }
    await sendOwnerEmail(email, status==='approved'?'Seu app foi publicado no Portis dunte':status==='rejected'?'Seu app não foi publicado no Portis dunte':'Recebemos seu app — análise pendente', `Olá!\n\nRecebemos o aplicativo: ${name}\nFormato: ${platform}\nIdentificador: ${pkg}\n\nResultado: ${status==='approved'?'PUBLICADO':status==='rejected'?'RECUSADO':'AGUARDANDO ANÁLISE'}\nMotivo: ${reason}\n\n${status==='pending'?'Ele não ficará disponível até a análise ser concluída.':''}\n\nPortis dunte`);
    return NextResponse.json({message:status==='approved'?'Aplicativo verificado e publicado! Enviamos um e-mail com o resultado.':status==='rejected'?'O aplicativo foi recusado pela verificação. Enviamos o motivo por e-mail.':'Aplicativo recebido! Ele ficará aguardando análise adicional. Enviamos um e-mail com o status.'});
  } catch (e) { console.error(e); return NextResponse.json({error:e instanceof Error?e.message:'Erro interno ao publicar.'},{status:500}); }
}
