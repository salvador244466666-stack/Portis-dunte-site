import { NextResponse } from 'next/server';
import { supabase } from '@/lib/server';
export const dynamic = 'force-dynamic';
export async function GET(){
  try {
    const db=supabase();
    const {data,error}=await db.from('apps').select('id,name,platform,package_name,description,contact,image_path,created_at').eq('status','approved').order('created_at',{ascending:false}).limit(60);
    if(error) throw error;
    const apps=await Promise.all((data||[]).map(async a=>{const {data:image}=await db.storage.from('portis-files').createSignedUrl(a.image_path,3600);return {...a,image_url:image?.signedUrl||null};}));
    return NextResponse.json({apps});
  }catch(e){console.error(e);return NextResponse.json({apps:[],error:'Configure o banco de dados para carregar os aplicativos.'},{status:500});}
}
