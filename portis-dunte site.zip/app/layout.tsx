import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Portis dunte — Apps para todos', description: 'Descubra e publique aplicativos APK, IPA e EXE.' };
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
