'use client';
import { useEffect, useState } from 'react';

type AppItem = { id:string; name:string; platform:string; package_name:string; description:string|null; contact:string|null; image_url:string|null; created_at:string };
export default function Home() {
  const [apps,setApps] = useState<AppItem[]>([]);
  const [loading,setLoading] = useState(true);
  const [show,setShow] = useState(false);
  const [notice,setNotice] = useState('');
  const [busy,setBusy] = useState(false);
  async function load(){ setLoading(true); try { const r=await fetch('/api/apps'); const d=await r.json(); setApps(d.apps||[]); } catch {} setLoading(false); }
  useEffect(()=>{ load(); },[]);
  async function submit(e:React.FormEvent<HTMLFormElement>){
    e.preventDefault(); setBusy(true); setNotice('Enviando arquivo para verificação...');
    const form=new FormData(e.currentTarget);
    try { const r=await fetch('/api/submit',{method:'POST',body:form}); const d=await r.json(); if(!r.ok) throw new Error(d.error||'Não foi possível enviar.'); setNotice(d.message); (e.target as HTMLFormElement).reset(); setShow(false); await load(); }
    catch(err){setNotice(err instanceof Error?err.message:'Erro inesperado.');} finally{setBusy(false);}
  }
  return <main>
    <nav className="nav"><a className="brand" href="#top"><span className="brand-icon">P</span> Portis dunte</a><div className="nav-actions"><a href="#apps">Explorar</a><button className="small-btn" onClick={()=>{setShow(true);setNotice('')}}>＋ Publicar app</button></div></nav>
    <section className="hero" id="top"><div className="hero-copy"><span className="eyebrow">SUA PRÓXIMA DESCOBERTA COMEÇA AQUI</span><h1>Aplicativos feitos<br/>para <em>compartilhar.</em></h1><p>Descubra projetos da comunidade ou publique seu próprio aplicativo. APK, IPA e EXE em um só lugar.</p><button className="primary" onClick={()=>setShow(true)}>＋ Publicar aplicativo</button></div><div className="hero-art"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="app-tile tile-a">🤖<small>ANDROID</small></div><div className="app-tile tile-b">🍎<small>iOS</small></div><div className="app-tile tile-c">🖥️<small>WINDOWS</small></div><div className="hero-center">P<span>+</span></div></div></section>
    <section className="trust"><div><b>01</b><span>Publique seu projeto</span></div><div><b>02</b><span>Verificação automática</span></div><div><b>03</b><span>Compartilhe com todos</span></div></section>
    <section className="apps-section" id="apps"><div className="section-heading"><div><span className="eyebrow">VITRINE DA COMUNIDADE</span><h2>Aplicativos publicados</h2></div><span className="count">{apps.length} publicados</span></div>
      {loading?<p className="empty">Carregando aplicativos...</p>:apps.length===0?<div className="empty"><div className="empty-icon">✦</div><h3>O primeiro app pode ser o seu!</h3><p>Ainda não há aplicativos publicados. Envie o seu para começar.</p><button className="primary" onClick={()=>setShow(true)}>Publicar primeiro app</button></div>:<div className="app-grid">{apps.map(a=><article className="app-card" key={a.id}><div className="app-image">{a.image_url?<img src={a.image_url} alt=""/>:<span>▣</span>}<label>{a.platform}</label></div><div className="app-info"><h3>{a.name}</h3><p>{a.description||'Sem descrição.'}</p><small>{a.package_name}</small>{a.contact&&<p className="contact">Contato: {a.contact}</p>}<a className="download" href={`/api/download/${a.id}`}>Baixar aplicativo <span>↗</span></a></div></article>)}</div>}</section>
    <footer><a className="brand" href="#top"><span className="brand-icon">P</span> Portis dunte</a><span>Compartilhe com responsabilidade. Verifique os arquivos antes de instalar.</span><span>© 2026 Portis dunte</span></footer>
    {show&&<div className="modal-backdrop" onClick={e=>{if(e.target===e.currentTarget)setShow(false)}}><div className="modal"><button className="close" onClick={()=>setShow(false)}>×</button><span className="eyebrow">CONTRIBUA COM A COMUNIDADE</span><h2>Publicar aplicativo</h2><p className="modal-sub">Preencha os dados. A publicação passará por verificações automáticas.</p><form onSubmit={submit}>
      <label>Formato do aplicativo *</label><select name="platform" required defaultValue=""><option value="" disabled>Selecione o formato</option><option value="APK">APK — Android</option><option value="IPA">IPA — iOS</option><option value="EXE">EXE — Windows</option></select>
      <label>Nome do aplicativo *</label><input name="name" required maxLength={70} placeholder="Ex.: Meu aplicativo"/>
      <label>Identificador do pacote *</label><input name="package_name" required maxLength={160} placeholder="Ex.: com.exemplo.meuapp"/><small className="hint">Para EXE, informe um identificador único, como nome.empresa.app.</small>
      <label>Arquivo do aplicativo *</label><input name="file" type="file" required accept=".apk,.ipa,.exe"/><small className="hint">Máximo de 100 MB. Envie somente arquivos que você tem direito de compartilhar.</small>
      <label>Imagem do aplicativo *</label><input name="image" type="file" required accept="image/png,image/jpeg,image/webp"/>
      <label>Descrição <span>(opcional)</span></label><textarea name="description" maxLength={1000} placeholder="Conte o que seu aplicativo faz..."></textarea>
      <label>Seu e-mail para receber o resultado *</label><input name="email" type="email" required placeholder="voce@email.com"/>
      <label>Contato público <span>(opcional)</span></label><input name="contact" maxLength={120} placeholder="Site, Discord ou outro contato"/>
      <label className="check"><input type="checkbox" name="rights" required/> Confirmo que tenho autorização para compartilhar este arquivo e que ele não foi criado para prejudicar outras pessoas.</label>
      <button className="primary full" disabled={busy}>{busy?'Verificando...':'Enviar para verificação'}</button>
      {notice&&<p className="notice">{notice}</p>}
    </form></div></div>}
  </main>;
}
