-- Execute no SQL Editor do seu projeto Supabase.
create table if not exists public.apps (
  id uuid primary key,
  name text not null,
  platform text not null check (platform in ('APK','IPA','EXE')),
  package_name text not null,
  description text,
  contact text,
  owner_email text not null,
  file_path text not null,
  image_path text not null,
  sha256 text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  moderation_reason text,
  created_at timestamptz not null default now()
);
create index if not exists apps_public_list on public.apps(status, created_at desc);

-- Crie também um bucket PRIVADO chamado: portis-files
-- Não habilite acesso público. A aplicação gera links temporários para downloads aprovados.
