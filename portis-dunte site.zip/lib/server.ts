import { createClient } from '@supabase/supabase-js';

export function supabase() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error('Configure SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY.');
  return createClient(url, key, { auth: { persistSession: false } });
}

export async function sendOwnerEmail(to: string, subject: string, message: string) {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  if (!apiKey || !from) return;
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from, to: [to], subject, text: message })
  });
  if (!response.ok) console.error('Falha ao enviar e-mail:', await response.text());
}

export async function checkVirusTotal(buffer: Buffer): Promise<{status:'clean'|'malicious'|'unknown'; reason:string}> {
  const key = process.env.VIRUSTOTAL_API_KEY;
  if (!key) return { status: 'unknown', reason: 'Verificação antivírus externa não configurada.' };
  const hash = (await import('node:crypto')).createHash('sha256').update(buffer).digest('hex');
  try {
    const res = await fetch(`https://www.virustotal.com/api/v3/files/${hash}`, { headers: { 'x-apikey': key } });
    if (res.status === 404) return { status: 'unknown', reason: 'Arquivo ainda não consta na base de análise.' };
    if (!res.ok) return { status: 'unknown', reason: 'Não foi possível consultar a análise antivírus.' };
    const data = await res.json();
    const stats = data?.data?.attributes?.last_analysis_stats;
    if (!stats) return { status: 'unknown', reason: 'Resultado antivírus indisponível.' };
    const bad = Number(stats.malicious || 0) + Number(stats.suspicious || 0);
    if (bad > 0) return { status: 'malicious', reason: `A análise encontrou ${bad} detecção(ões) suspeita(s)/maliciosa(s).` };
    return { status: 'clean', reason: 'A análise consultada não apontou detecções. Isso não garante segurança total.' };
  } catch {
    return { status: 'unknown', reason: 'Erro ao consultar o serviço antivírus.' };
  }
}
